package svd;

import Jama.Matrix;

import java.io.*;
import java.rmi.server.ExportException;
import java.util.*;
//program that uses command-line arguments that separates the tasks
public class SVD {
    static String fileName; //fileName from command line
    static int choice; //choice to perform particular task from command line
    static String newFile; //newFile name for converted file
    static String headerFile; //headerFile name
    static String svdFile; //svdFile name
    static int rank; //rank of matrix
    public static void main(String[] args) throws Exception{
        //if(args.length > 0){
        if(true){
            //choice = Integer.parseInt(args[0]);
            //switch (choice){
            switch (4){
                case 1:
                    fileName = "CAS2.pgm";//args[1];
                    convertToBinary(fileName);
                    break;
                case 2:
                    fileName = "CAS2_b.pgm";//args[1];
                    convertToAscii(fileName);
                    break;
                case 3:
                    headerFile = "header.txt";
                    svdFile = "SVD.txt";
                    rank = 5;
                    compressFile();
                    break;
                case 4:
                    readCompressedBinImage();
                    break;
                default:
                    System.out.println("Input format is not correct");
                    break;
            }
        }
        else
            System.out.println("Input format is not correct");
    }

    private static void compressFile() throws Exception {
        int k=376;
        FileInputStream fileInputStream1 = new FileInputStream("header.txt");
        Scanner scanner1 = new Scanner(fileInputStream1);
        int width = Integer.parseInt(scanner1.next());
        int height = Integer.parseInt(scanner1.next());
        fileInputStream1.close();

        FileInputStream fileInputStream2 = new FileInputStream("SVD.txt");
        Scanner scanner2 = new Scanner(fileInputStream2);

        byte [] metaBytes = new byte[6];
        metaBytes[0] = (byte) (width & 0xFF);
        metaBytes[1] = (byte) ((width >> 8) & 0xFF);
        metaBytes[2] = (byte) (height & 0xFF);
        metaBytes[3] = (byte) ((height >> 8) & 0xFF);
        metaBytes[4] = (byte) (k & 0xFF);
        metaBytes[5] = (byte) ((k >> 8) & 0xFF);

        byte[] uBytes = new byte[2 * height * k];
        int count=0;
        for(int i=0;i<height;i++){
            String line = scanner2.nextLine();
            String[] vals = line.trim().split(" ");
            for(int j=0;j<k;j++){
                byte [] b = float2bytes(Float.parseFloat(vals[j]));
                uBytes[count++]=b[0];
                uBytes[count++]=b[1];
            }
        }

        byte[] sBytes = new byte[2*k];
        count=0;
        {
            String line = scanner2.nextLine();
            String[] vals = line.trim().split(" ");
            for (int j = 0; j < k; j++) {
                byte[] b = float2bytes(Float.parseFloat(vals[j]));
                sBytes[count++] = b[0];
                sBytes[count++] = b[1];
            }
        }

        byte[] vBytes = new byte[2 * width * k];
        count=0;
        for(int i=0;i<k;i++){
            String line = scanner2.nextLine();
            String[] vals = line.trim().split(" ");
            for(int j=0;j<vals.length;j++){
                byte [] b = float2bytes(Float.parseFloat(vals[j]));
                vBytes[count++]=b[0];
                vBytes[count++]=b[1];
            }
        }
        byte[] bytes = new byte[metaBytes.length+uBytes.length + sBytes.length + vBytes.length];
        System.arraycopy(metaBytes, 0, bytes, 0, metaBytes.length);
        System.arraycopy(uBytes, 0, bytes, metaBytes.length, uBytes.length);
        System.arraycopy(sBytes, 0, bytes, metaBytes.length+uBytes.length, sBytes.length);
        System.arraycopy(vBytes, 0, bytes, metaBytes.length+ uBytes.length + sBytes.length, vBytes.length);

        String fname = "image_b.pgm.SVD";

        File f = new File(fname);
        FileOutputStream outputStream = new FileOutputStream(f);
        outputStream.write(bytes);
        outputStream.flush();
        outputStream.close();
    }

    private static void readCompressedBinImage() throws Exception{
        File file = new File("image_b.pgm.SVD");
        FileInputStream fileInputStream = new FileInputStream(file);
        //source -- https://howtodoinjava.com/java/io/how-to-read-file-content-into-byte-array-in-java/
        byte[] fileContent = new byte[(int)file.length()];
        fileInputStream.read(fileContent);
        fileInputStream.close();
        int width = ((fileContent[1] << 8) + (fileContent[0] & 0xff));
        int height = ((fileContent[3] << 8) + (fileContent[2] & 0xff));
        int k = ((fileContent[5] << 8) + (fileContent[4] & 0xff));

        int fileIndex=6;
        double U[][] = new double[height][height];
        double S[][] = new double[height][width];
        double V[][] = new double[width][width];

        for(int i=0;i<height;i++){
            for(int j=0;j<height;j++){
                if(j<k) {
                    double val = bytes2float(new byte[] { fileContent[fileIndex], fileContent[fileIndex+1]});
                    U[i][j]=val;
                    fileIndex += 2;
                }
                else{
                    U[i][j]=0;
                }
            }
        }


        for(int i=0;i<height;i++){
            for(int j=0;j<width;j++){
                if(i==j&&i<k) {
                    double val = bytes2float(new byte[] { fileContent[fileIndex], fileContent[fileIndex+1]});
                    S[i][j]=val;
                    fileIndex += 2;
                }
                else{
                    S[i][j]=0;
                }
            }
        }

        for(int i=0;i<width;i++){
            for(int j=0;j<width;j++){
                if(i<k) {
                    double val = bytes2float(new byte[] { fileContent[fileIndex], fileContent[fileIndex+1]});
                    V[i][j]=val;
                    fileIndex += 2;
                }
                else{
                    V[i][j]=0;
                }
            }
        }

        Matrix _U = new Matrix(U);
        Matrix _S = new Matrix(S);
        Matrix _V = new Matrix(V);

        Matrix image = _U.times(_S.times(_V));

        File file1 = new File("compressed.pgm");
        FileWriter fw = new FileWriter(file1);
        fw.write("test\n");
        fw.write(width+" "+height+"\n");
        fw.write("255\n");
        double abc[][]=image.getArray();
        for(int i=0;i<abc.length;i++){
            for(int j=0;j<abc[0].length;j++){
                System.out.print(abc[i][j] + "  ");
                fw.write((int)abc[i][j]+" ");
            }
            System.out.print("\n");
        }
        fw.close();
    }
    public static float bytes2float(byte[] bytes) {
        int bits = bytes[0] << 8 | (bytes[1] & 0xFF);
        int mant = bits & 0x03ff; /* 10 bits mantissa */
        int exp = bits & 0x7c00; /* 5 bits exponent */
        if (exp == 0x7c00) /* NaN or Inf */
            exp = 0x3fc00;
        else if (exp != 0) { /* normalized value, exp = exp - 15 + 127 */
            exp += 0x1c000;
            if (mant == 0 && exp > 0x1c400) // smooth transition
                return Float.intBitsToFloat((bits & 0x8000) << 16 | exp << 13 | 0x3ff);
        } else if (mant != 0) {// && exp==0 -> subnormal
            exp = 0x1c400; // make it normal
            do {
                mant <<= 1; // mantissa * 2
                exp -= 0x400; // decrease exp by 1
            } while ((mant & 0x400) == 0); // while not normal
            mant &= 0x3ff; // discard subnormal bit
        } // else +/-0 -> +/-0

        return Float.intBitsToFloat( // combine all parts
                (bits & 0x8000) << 16 // sign << ( 31 - 15 )
                        | (exp | mant) << 13); // value << ( 23 - 10 )
    }


    public static byte[] float2bytes(float fval) {
        int fbits = Float.floatToIntBits(fval);
        int sign = fbits >>> 16 & 0x8000; // sign only
        int val = (fbits & 0x7fffffff) + 0x1000; // rounded value
        int bits = 0;

        if (val >= 0x47800000) {
            // might be or become NaN/Inf
            // avoid Inf due to rounding
            if ((fbits & 0x7fffffff) >= 0x47800000) { // is or must become NaN/Inf
                if (val < 0x7f800000) // was value but too large
                    bits = sign | 0x7c00; // make it +/-Inf
                else
                    bits = sign | 0x7c00 | // remains +/-Inf or NaN
                            (fbits & 0x007fffff) >>> 13; // keep NaN (and Inf) bits
            } else
                bits = sign | 0x7bff; // unrounded not quite Inf
        } else if (val >= 0x38800000) // remains normalized value
            bits = sign | val - 0x38000000 >>> 13; // exp - 127 + 15
        else if (val < 0x33000000) // too small for subnormal
            bits = sign; // becomes +/-0
        else {
            val = (fbits & 0x7fffffff) >>> 23; // tmp exp for subnormal calc
            bits = sign | ((fbits & 0x7fffff | 0x800000) // add subnormal bit
                    + (0x800000 >>> val - 102) // round depending on cut off
                    >>> 126 - val); // div by 2^(1-(exp-127+15)) and >> 13 | exp=0
        }

        byte[] bytes = new byte[2];
        bytes[0] = (byte) (bits >>> 8);
        bytes[1] = (byte) bits;
        return bytes;
    }


    //program that converts ascii .pgm file to binary .pgm file
    //SUPPOSED TO IGNORE COMMENTS -- NEEDS FIX
    private static void convertToBinary(String fileName) throws FileNotFoundException{
        newFile =  fileName.replace(".pgm", "_b.pgm");
        //source - https://stackoverflow.com/questions/3639198/how-to-read-pgm-images-in-java
        FileInputStream fileInputStream = new FileInputStream(fileName);
        Scanner scanner = new Scanner(fileInputStream);
        scanner.nextLine(); // skip line one
        int width = Integer.parseInt(scanner.next());
        int height = Integer.parseInt(scanner.next());
        int maxValue = Integer.parseInt(scanner.next());
        //to store bytes
        byte[] byteArray = new byte[width*height+5];
        //convert width into 2 byte binary
        //source - https://stackoverflow.com/questions/1735840/how-do-i-split-an-integer-into-2-byte-binary
        byteArray[0] = (byte) (width & 0xFF);
        byteArray[1] = (byte) ((width >> 8) & 0xFF);
        //convert height into 2 byte binary
        byteArray[2] = (byte) (height & 0xFF);
        byteArray[3] = (byte) ((height >> 8) & 0xFF);
        //convert maxValue into 1 byte binary
        byteArray[4] = (byte) maxValue;
        //store pixels
        int count = 5;
        for(int i=0; i<height; i++){
            for (int j=0; j<width; j++){
                int pixelValue = scanner.nextInt();
                byteArray[count++] = (byte) pixelValue;
            }
        }
        //write byteArray data to newFile
        DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(newFile));
        try {
            dataOutputStream.write(byteArray);
            dataOutputStream.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    //program that converts binary .pgm file to ascii .pgm file
    private static void convertToAscii(String fileName) throws IOException{
        newFile = fileName.replace("_b.pgm", "_copy.pgm");
        File file = new File(fileName);
        FileInputStream fileInputStream = new FileInputStream(file);
        //source -- https://howtodoinjava.com/java/io/how-to-read-file-content-into-byte-array-in-java/
        byte[] fileContent = new byte[(int)file.length()];
        fileInputStream.read(fileContent);
        fileInputStream.close();
        //source -- https://stackoverflow.com/questions/2885173/how-do-i-create-a-file-and-write-to-it-in-java
        PrintWriter writer = new PrintWriter(newFile);
        writer.println("P2");
        //source -- https://stackoverflow.com/questions/4768933/read-two-bytes-into-an-integer
        int width = ((fileContent[1] << 8) + (fileContent[0] & 0xff));
        int height = ((fileContent[3] << 8) + (fileContent[2] & 0xff));
        writer.println(width+" "+height);
        int maxValue = fileContent[4] & 0xFF;
        writer.println(Integer.toString(maxValue));
        //convert pixel values
        int count = 5;
        for(int i=0; i<height; i++){
            for (int j=0; j<width; j++){
                int rowValue = (fileContent[count++] & 0xFF);
                writer.print(rowValue + " ");
            }
            writer.println();
        }
        writer.close();
    }
}
