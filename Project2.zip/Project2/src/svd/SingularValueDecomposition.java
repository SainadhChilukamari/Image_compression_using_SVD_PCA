package svd;

import Jama.Matrix;
import org.jblas.FloatMatrix;
import org.jblas.Singular;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class SingularValueDecomposition {
    public static void main(String[] args) {
        if(true){
            String filename = "baboon.pgm";
            String headerFileName = "header.txt";
            String svdFileName = "SVD.txt";

            File file = new File(filename);

            try {
                Scanner sc = new Scanner(file);
                sc.nextLine(); // skip line 1
                String line="";

                int width = Integer.parseInt(sc.next());
                int height = Integer.parseInt(sc.next());
                int maxValue = Integer.parseInt(sc.next());
                FileWriter fw1 = new FileWriter(new File(headerFileName));
                fw1.write(width+" "+height+"\n");
                fw1.write(maxValue);
                fw1.close();

                double pixelVal[][]=new double[height][width];
                for(int i=0; i<height; i++){
                    for (int j=0; j<width; j++){
                        pixelVal[i][j]= sc.nextInt();
                    }
                }

                Matrix image = new Matrix(pixelVal);
                Jama.SingularValueDecomposition svd = new Jama.SingularValueDecomposition(image);
                FileWriter fw2 = new FileWriter(new File(svdFileName));

                Matrix U = svd.getU();
                double[][] uMatrix = U.getArray();
                for(int i=0;i<uMatrix.length;i++){
                    for(int j=0;j<uMatrix[0].length;j++){
                        fw2.write((float)uMatrix[i][j]+" ");
                    }
                    fw2.write("\n");
                }

                /*double[] sMatrix = svd.getSingularValues();
                for(int i=0;i<height;i++){
                    fw2.write((float)sMatrix[i]+" ");
                }
                fw2.write("\n");*/

                Matrix S = svd.getS();
                double[][] sMatrix = S.getArray();
                for(int i=0;i<sMatrix.length;i++){
                    for(int j=0;j<sMatrix[0].length;j++){
                        fw2.write((float)sMatrix[i][j]+" ");
                    }
                    fw2.write("\n");
                }

                Matrix V = svd.getV().transpose();
                double[][] vMatrix = V.getArray();
                for(int i=0;i<vMatrix.length;i++){
                    for(int j=0;j<vMatrix[0].length;j++){
                        fw2.write((float)vMatrix[i][j]+" ");
                    }
                    fw2.write("\n");
                }

                fw2.close();

                Matrix _image = U.times(S.times(V.));
                double[] [] abc = _image.getArray();
                for(int i=0;i<abc.length;i++){
                    for(int j=0;j<abc[0].length;j++){
                        System.out.print(abc[i][j] + "  ");
                    }
                    System.out.print("\n");
                }

            }
            catch(Exception e){
                e.printStackTrace();
            }

        }
        else{
            System.out.println("Enter filename");
        }
    }
}
